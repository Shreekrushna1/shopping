export class CartModel {
  name: string;
  price: number;
  quantity: number;
}
