export const inventory = [
    {
      name: 'Bread',
      image: 'bread.jfif',
      price: 3.6,
      category: ['Dairy'],
    },
    {
      name: 'Chips',
      image: 'chips.jfif',
      price: 2.5,
      category: ['Snack'],
    },
    {
      name: 'Milk',
      image: 'milk.jfif',
      price: 1,
      category: ['Dairy'],
    },
    {
      name: 'Egg',
      image: 'egg.jfif',
      price: 4.5,
      category: ['Dairy'],
    },
    {
      name: 'Apple',
      image: 'apple.jfif',
      price: 0.2,
      category: ['Fruit'],
    },
    {
      name: 'Chocolate',
      image: 'chocolate.jfif',
      price: 5,
      category: ['Dairy', 'Snack'],
    },
  ];
  